<?php

namespace App\Repository;

/**
 * Class memberRepository
 *
 * @package \App\Repository
 */
class memberRepository
{



}
